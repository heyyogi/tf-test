#!/bin/bash

# Deployment script for Strapi Terraform infrastructure
# Usage: ./deploy.sh [dev|staging|prod] [plan|apply|destroy]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check arguments
if [ $# -lt 2 ]; then
    print_error "Usage: ./deploy.sh [dev|staging|prod] [plan|apply|destroy]"
    exit 1
fi

ENVIRONMENT=$1
ACTION=$2

# Validate environment
if [[ ! "$ENVIRONMENT" =~ ^(dev|staging|prod)$ ]]; then
    print_error "Invalid environment. Must be: dev, staging, or prod"
    exit 1
fi

# Validate action
if [[ ! "$ACTION" =~ ^(plan|apply|destroy)$ ]]; then
    print_error "Invalid action. Must be: plan, apply, or destroy"
    exit 1
fi

TFVARS_FILE="terraform.${ENVIRONMENT}.tfvars"

# Check if tfvars file exists
if [ ! -f "$TFVARS_FILE" ]; then
    print_error "Configuration file $TFVARS_FILE not found!"
    exit 1
fi

print_info "Starting Terraform $ACTION for $ENVIRONMENT environment..."
echo ""

# Initialize Terraform if needed
if [ ! -d ".terraform" ]; then
    print_info "Initializing Terraform..."
    terraform init
    echo ""
fi

# Execute Terraform command
case $ACTION in
    plan)
        print_info "Running Terraform plan..."
        terraform plan -var-file="$TFVARS_FILE" -out="${ENVIRONMENT}.tfplan"
        print_info "Plan saved to ${ENVIRONMENT}.tfplan"
        print_warn "Review the plan above before applying!"
        ;;
    
    apply)
        # Check if plan file exists
        if [ -f "${ENVIRONMENT}.tfplan" ]; then
            print_info "Applying Terraform plan from ${ENVIRONMENT}.tfplan..."
            terraform apply "${ENVIRONMENT}.tfplan"
            rm -f "${ENVIRONMENT}.tfplan"
        else
            print_info "Running Terraform apply..."
            terraform apply -var-file="$TFVARS_FILE"
        fi
        
        echo ""
        print_info "Deployment completed successfully!"
        echo ""
        print_info "Getting outputs..."
        terraform output
        echo ""
        print_info "Access Strapi at: $(terraform output -raw alb_url)"
        ;;
    
    destroy)
        print_warn "WARNING: This will destroy all resources in $ENVIRONMENT environment!"
        read -p "Are you sure? Type 'yes' to confirm: " -r
        echo
        if [[ $REPLY == "yes" ]]; then
            print_info "Destroying infrastructure..."
            terraform destroy -var-file="$TFVARS_FILE"
            print_info "Infrastructure destroyed successfully!"
        else
            print_info "Destroy cancelled."
        fi
        ;;
esac

echo ""
print_info "Done!"
