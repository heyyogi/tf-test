# Strapi on AWS with Terraform

This Terraform configuration deploys a production-ready Strapi CMS on AWS with proper network architecture, security, and high availability.

## Architecture Overview

### Components

1. **VPC Architecture**
   - Custom VPC with configurable CIDR block
   - Public subnets (2-3 AZs) for Application Load Balancer
   - Private subnets (2-3 AZs) for EC2 instances
   - Internet Gateway for public internet access
   - NAT Gateways (one per AZ) for private subnet outbound access

2. **Compute**
   - EC2 instance in private subnet running Docker
   - Strapi CMS running in Docker container
   - IAM role with SSM access for secure management
   - CloudWatch agent for monitoring and logging

3. **Load Balancing**
   - Application Load Balancer in public subnets
   - Target group with health checks
   - HTTP listener (can be extended to HTTPS)

4. **Security**
   - Security group for ALB (allows HTTP/HTTPS from internet)
   - Security group for EC2 (allows traffic only from ALB)
   - Private subnet isolation
   - Encrypted EBS volumes
   - IMDSv2 enforced

5. **Networking**
   - Route tables for public and private subnets
   - NAT Gateway for secure outbound internet access
   - VPC DNS enabled

## Architecture Diagram

```
Internet
    |
    v
[Internet Gateway]
    |
    v
[Application Load Balancer] (Public Subnets)
    |
    v
[EC2 Instance - Strapi] (Private Subnet)
    |
    v
[NAT Gateway] -> Internet
```

## Prerequisites

1. **AWS Account** with appropriate permissions
2. **Terraform** >= 1.0 installed
3. **AWS CLI** configured with credentials
4. **SSH Key Pair** generated (your public key)

### Generate SSH Key Pair

```bash
ssh-keygen -t rsa -b 4096 -C "your-email@example.com" -f ~/.ssh/strapi-key
```

### Generate Strapi Secrets

Generate secure secrets for Strapi:

```bash
# Generate multiple secrets
for i in {1..5}; do
  openssl rand -base64 32
done
```

## Directory Structure

```
terraform-strapi-deployment/
├── main.tf                     # Main Terraform configuration
├── variables.tf                # Variable definitions
├── outputs.tf                  # Output definitions
├── user_data.sh               # EC2 bootstrap script
├── terraform.dev.tfvars       # Development environment variables
├── terraform.staging.tfvars   # Staging environment variables
├── terraform.prod.tfvars      # Production environment variables
└── README.md                  # This file
```

## Configuration

### 1. Update Environment Variables

Edit the appropriate `.tfvars` file for your environment:

**For Development:**
```bash
vim terraform.dev.tfvars
```

**Required Updates:**
- Replace `ssh_public_key` with your actual SSH public key
- Generate and replace all Strapi secrets (APP_KEYS, JWT_SECRET, etc.)
- Update `ssh_allowed_cidr` to your bastion/VPN CIDR if needed
- Configure database settings if using external database

### 2. Strapi Secret Configuration

Update these values in your `.tfvars` file:

```hcl
strapi_app_keys           = "key1,key2,key3,key4"  # 4 random strings
strapi_api_token_salt     = "your-api-token-salt"
strapi_admin_jwt_secret   = "your-admin-jwt-secret"
strapi_transfer_token_salt = "your-transfer-token-salt"
strapi_jwt_secret         = "your-jwt-secret"
```

### 3. Database Configuration

**Development (SQLite):**
```hcl
strapi_database_client = "sqlite"
```

**Production (PostgreSQL - Recommended):**
```hcl
strapi_database_client   = "postgres"
strapi_database_host     = "your-rds-endpoint.region.rds.amazonaws.com"
strapi_database_port     = 5432
strapi_database_name     = "strapi_prod"
strapi_database_username = "strapiuser"
strapi_database_password = "your-secure-password"
```

## Deployment

### Initialize Terraform

```bash
cd terraform-strapi-deployment
terraform init
```

### Plan Deployment

**For Development:**
```bash
terraform plan -var-file="terraform.dev.tfvars"
```

**For Staging:**
```bash
terraform plan -var-file="terraform.staging.tfvars"
```

**For Production:**
```bash
terraform plan -var-file="terraform.prod.tfvars"
```

### Apply Configuration

```bash
terraform apply -var-file="terraform.dev.tfvars"
```

Review the plan and type `yes` to confirm.

### Deployment Time

- Initial deployment: ~10-15 minutes
- EC2 instance startup + Docker installation: ~5-10 minutes
- Strapi container startup: ~2-3 minutes

**Total: ~20-25 minutes**

## Post-Deployment

### 1. Get ALB URL

```bash
terraform output alb_url
```

Access Strapi at: `http://<alb-dns-name>`

### 2. Access Strapi Admin

1. Open the ALB URL in your browser
2. Navigate to `/admin`
3. Create your first admin user

### 3. Connect to EC2 Instance

**Using AWS Systems Manager (Recommended):**
```bash
aws ssm start-session --target <instance-id> --region us-east-1
```

**Using SSH (requires bastion or VPN):**
```bash
ssh -i ~/.ssh/strapi-key ec2-user@<private-ip>
```

### 4. Check Docker Status

```bash
# SSH into instance first
docker ps
docker logs strapi
docker-compose -f /opt/strapi/docker-compose.yml ps
```

## Monitoring and Troubleshooting

### Check Strapi Logs

```bash
# On EC2 instance
docker logs strapi -f
```

### Check ALB Health

```bash
aws elbv2 describe-target-health \
  --target-group-arn <target-group-arn> \
  --region us-east-1
```

### CloudWatch Logs

Logs are sent to CloudWatch Logs group: `/aws/ec2/strapi`

### Health Check Endpoint

Strapi health check: `http://<alb-url>/_health`

## Customization

### Change Instance Type

Update in `.tfvars`:
```hcl
instance_type = "t3.large"
```

### Add More Availability Zones

Update in `.tfvars`:
```hcl
az_count = 3
```

### Enable HTTPS

1. Request ACM certificate
2. Add HTTPS listener to ALB:

```hcl
resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.main.arn
  port              = "443"
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS-1-2-2017-01"
  certificate_arn   = "arn:aws:acm:region:account:certificate/xxx"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.strapi.arn
  }
}
```

### Add RDS Database

Create an RDS instance and update the database configuration in your `.tfvars` file.

## Security Best Practices

1. **Secrets Management**: Use AWS Secrets Manager or Parameter Store for sensitive values
2. **HTTPS**: Enable HTTPS with ACM certificate
3. **Bastion Host**: Deploy a bastion host for SSH access to private instances
4. **VPN**: Use AWS Client VPN for secure access
5. **IAM Roles**: Use least privilege IAM roles
6. **Security Groups**: Regularly audit security group rules
7. **Backups**: Enable automated EBS snapshots and RDS backups
8. **Monitoring**: Set up CloudWatch alarms for critical metrics

## Cost Optimization

### Development Environment
- Use `t3.medium` instance
- Single NAT Gateway
- 2 Availability Zones

### Production Environment
- Use `t3.large` or larger
- NAT Gateway per AZ for high availability
- 3 Availability Zones
- Enable deletion protection

### Estimated Monthly Costs (us-east-1)

**Development:**
- EC2 t3.medium: ~$30
- NAT Gateway: ~$32
- ALB: ~$16
- EBS: ~$3
- **Total: ~$81/month**

**Production:**
- EC2 t3.large: ~$60
- NAT Gateways (3): ~$96
- ALB: ~$16
- EBS: ~$5
- RDS (if used): ~$50-200
- **Total: ~$177-327/month**

## Cleanup

To destroy all resources:

```bash
terraform destroy -var-file="terraform.dev.tfvars"
```

**Warning**: This will delete all resources including data stored on the EC2 instance.

## Environment Variables Reference

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `aws_region` | AWS region | No | us-east-1 |
| `project_name` | Project name for resources | No | strapi-app |
| `environment` | Environment (dev/staging/prod) | No | dev |
| `vpc_cidr` | VPC CIDR block | No | 10.0.0.0/16 |
| `az_count` | Number of AZs | No | 2 |
| `instance_type` | EC2 instance type | No | t3.medium |
| `ssh_public_key` | SSH public key | Yes | - |
| `strapi_app_keys` | Strapi APP_KEYS | Yes | - |
| `strapi_api_token_salt` | API token salt | Yes | - |
| `strapi_admin_jwt_secret` | Admin JWT secret | Yes | - |
| `strapi_jwt_secret` | JWT secret | Yes | - |

## Outputs

After deployment, Terraform provides these outputs:

- `vpc_id`: VPC identifier
- `alb_url`: Load balancer URL to access Strapi
- `alb_dns_name`: Load balancer DNS name
- `ec2_instance_id`: EC2 instance identifier
- `ec2_private_ip`: Private IP of EC2 instance
- `ssh_command`: SSH command to connect
- `ssm_connect_command`: SSM command to connect

## Troubleshooting

### Strapi Not Starting

1. Check Docker logs: `docker logs strapi`
2. Verify user data script ran: `cat /var/log/cloud-init-output.log`
3. Check environment variables: `docker exec strapi env`

### ALB Health Check Failing

1. Check target health: `aws elbv2 describe-target-health --target-group-arn <arn>`
2. Verify security groups allow traffic from ALB to EC2
3. Check Strapi is listening on correct port: `docker exec strapi netstat -tulpn`

### Cannot Connect to EC2

1. Use SSM Session Manager (recommended)
2. Verify security group allows SSH from your IP/bastion
3. Check route tables and NAT Gateway

## Additional Resources

- [Strapi Documentation](https://docs.strapi.io/)
- [AWS VPC Best Practices](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-security-best-practices.html)
- [Terraform AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)

## Support

For issues or questions:
1. Check Terraform plan output for errors
2. Review CloudWatch logs
3. Verify all required variables are set
4. Ensure AWS credentials are configured correctly

## License

This configuration is provided as-is for educational and deployment purposes.
