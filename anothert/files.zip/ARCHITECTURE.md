# AWS Infrastructure Architecture for Strapi

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                          Internet                                │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │
                              ▼
                    ┌─────────────────┐
                    │ Internet Gateway │
                    └─────────────────┘
                              │
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│ Public Subnet │   │ Public Subnet │   │ Public Subnet │
│   (AZ-1)      │   │   (AZ-2)      │   │   (AZ-3)      │
│               │   │               │   │               │
│  ┌─────────┐  │   │  ┌─────────┐  │   │  ┌─────────┐  │
│  │   ALB   │◄─┼───┼─►│   ALB   │◄─┼───┼─►│   ALB   │  │
│  └─────────┘  │   │  └─────────┘  │   │  └─────────┘  │
│               │   │               │   │               │
│  ┌─────────┐  │   │  ┌─────────┐  │   │  ┌─────────┐  │
│  │   NAT   │  │   │  │   NAT   │  │   │  │   NAT   │  │
│  │ Gateway │  │   │  │ Gateway │  │   │  │ Gateway │  │
│  └─────────┘  │   │  └─────────┘  │   │  └─────────┘  │
└───────┬───────┘   └───────┬───────┘   └───────┬───────┘
        │                   │                   │
        │                   ▼                   │
        │         ┌──────────────────┐          │
        └────────►│ Target Group     │◄─────────┘
                  │ (Health Checks)  │
                  └──────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│Private Subnet │   │Private Subnet │   │Private Subnet │
│   (AZ-1)      │   │   (AZ-2)      │   │   (AZ-3)      │
│               │   │               │   │               │
│  ┌─────────┐  │   │               │   │               │
│  │   EC2   │  │   │               │   │               │
│  │ Instance│  │   │               │   │               │
│  │         │  │   │               │   │               │
│  │ Docker  │  │   │               │   │               │
│  │ Strapi  │  │   │               │   │               │
│  └─────────┘  │   │               │   │               │
└───────────────┘   └───────────────┘   └───────────────┘
```

## Security Groups

```
┌──────────────────────────────────────────────────────┐
│              ALB Security Group                       │
│                                                       │
│  Ingress:                                            │
│  • HTTP (80)  from 0.0.0.0/0                         │
│  • HTTPS (443) from 0.0.0.0/0                        │
│                                                       │
│  Egress:                                             │
│  • All traffic to 0.0.0.0/0                          │
└──────────────────────────────────────────────────────┘
                        │
                        │ Port 1337
                        ▼
┌──────────────────────────────────────────────────────┐
│             EC2 Security Group                        │
│                                                       │
│  Ingress:                                            │
│  • Port 1337 from ALB Security Group                 │
│  • SSH (22) from VPC CIDR (10.0.0.0/16)             │
│                                                       │
│  Egress:                                             │
│  • All traffic to 0.0.0.0/0 (via NAT)               │
└──────────────────────────────────────────────────────┘
```

## Network Flow

### Inbound Traffic (User → Strapi)
1. User makes HTTP request to ALB DNS name
2. ALB receives traffic in public subnet
3. ALB forwards to target (EC2 instance) on port 1337
4. EC2 instance in private subnet receives request
5. Docker container (Strapi) processes request
6. Response flows back through ALB to user

### Outbound Traffic (EC2 → Internet)
1. EC2 instance initiates outbound connection
2. Traffic routes to NAT Gateway in same AZ
3. NAT Gateway translates private IP to public IP
4. Traffic flows through Internet Gateway
5. Response returns via same path

## Component Details

### VPC (Virtual Private Cloud)
- CIDR: 10.0.0.0/16 (65,536 IPs)
- DNS Support: Enabled
- DNS Hostnames: Enabled

### Subnets
**Public Subnets (Per AZ):**
- CIDR: 10.0.0.0/24, 10.0.1.0/24, 10.0.2.0/24
- Auto-assign public IP: Yes
- Route: 0.0.0.0/0 → Internet Gateway

**Private Subnets (Per AZ):**
- CIDR: 10.0.2.0/24, 10.0.3.0/24, 10.0.4.0/24
- Auto-assign public IP: No
- Route: 0.0.0.0/0 → NAT Gateway

### EC2 Instance
- AMI: Amazon Linux 2023
- Instance Type: t3.medium (configurable)
- Storage: 30 GB gp3 encrypted EBS
- IAM Role: SSM + CloudWatch access
- User Data: Installs Docker, runs Strapi

### Application Load Balancer
- Type: Application
- Scheme: Internet-facing
- Listeners: HTTP (80)
- Target Group: Port 1337
- Health Check: /_health endpoint

### High Availability Features
1. Multi-AZ deployment (2-3 zones)
2. NAT Gateway per AZ
3. ALB across all public subnets
4. Auto-recovery enabled on EC2

## Data Flow Diagram

```
User Request
     │
     ▼
[Route 53] (optional)
     │
     ▼
[ALB - HTTP:80]
     │
     ├─ Health Check: /_health
     │
     ▼
[Target Group]
     │
     ▼
[EC2 Security Group]
     │
     ▼
[EC2 Instance: 10.0.2.x]
     │
     ▼
[Docker Engine]
     │
     ▼
[Strapi Container: Port 1337]
     │
     ├─ SQLite (dev)
     └─ PostgreSQL (prod)
```

## Monitoring & Logging

```
┌─────────────────┐
│  EC2 Instance   │
│                 │
│  CloudWatch     │───────► CloudWatch Logs
│  Agent          │         /aws/ec2/strapi
└─────────────────┘
         │
         ▼
┌─────────────────┐
│ CloudWatch      │
│ Metrics         │
│                 │
│ • CPU           │
│ • Memory        │
│ • Network       │
│ • Disk          │
└─────────────────┘
```

## Deployment Environments

### Development
- 2 AZs
- t3.medium instance
- 1 NAT Gateway
- SQLite database
- Cost: ~$81/month

### Staging
- 2 AZs
- t3.medium instance
- 2 NAT Gateways
- PostgreSQL RDS (optional)
- Cost: ~$120/month

### Production
- 3 AZs
- t3.large+ instance
- 3 NAT Gateways
- PostgreSQL RDS
- Deletion protection enabled
- Cost: ~$177-327/month
