#!/bin/bash

# Script to generate Strapi secrets
# Usage: ./generate-secrets.sh

echo "==================================="
echo "Strapi Secret Generator"
echo "==================================="
echo ""
echo "Copy these values into your terraform.tfvars file:"
echo ""

echo "# Strapi Secrets (Generated on $(date))"
echo ""

# Generate APP_KEYS (4 keys)
echo "strapi_app_keys = \"$(openssl rand -base64 16),$(openssl rand -base64 16),$(openssl rand -base64 16),$(openssl rand -base64 16)\""

# Generate API_TOKEN_SALT
echo "strapi_api_token_salt = \"$(openssl rand -base64 32)\""

# Generate ADMIN_JWT_SECRET
echo "strapi_admin_jwt_secret = \"$(openssl rand -base64 32)\""

# Generate TRANSFER_TOKEN_SALT
echo "strapi_transfer_token_salt = \"$(openssl rand -base64 32)\""

# Generate JWT_SECRET
echo "strapi_jwt_secret = \"$(openssl rand -base64 32)\""

echo ""
echo "==================================="
echo "IMPORTANT: Keep these secrets secure!"
echo "Do not commit them to version control."
echo "==================================="
