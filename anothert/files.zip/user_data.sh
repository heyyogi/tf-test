#!/bin/bash
set -e

# Update system
echo "=== Updating system packages ==="
dnf update -y

# Install Docker
echo "=== Installing Docker ==="
dnf install -y docker

# Start and enable Docker
echo "=== Starting Docker service ==="
systemctl start docker
systemctl enable docker

# Add ec2-user to docker group
usermod -aG docker ec2-user

# Install Docker Compose
echo "=== Installing Docker Compose ==="
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# Create application directory
echo "=== Setting up application directory ==="
mkdir -p /opt/strapi
cd /opt/strapi

# Create docker-compose.yml
echo "=== Creating Docker Compose configuration ==="
cat > /opt/strapi/docker-compose.yml <<'EOF'
version: '3.8'

services:
  strapi:
    image: strapi/strapi:latest
    container_name: strapi
    restart: unless-stopped
    environment:
      - NODE_ENV=${node_env}
      - APP_KEYS=${app_keys}
      - API_TOKEN_SALT=${api_token_salt}
      - ADMIN_JWT_SECRET=${admin_jwt_secret}
      - TRANSFER_TOKEN_SALT=${transfer_token_salt}
      - JWT_SECRET=${jwt_secret}
      - DATABASE_CLIENT=${database_client}
      - DATABASE_HOST=${database_host}
      - DATABASE_PORT=${database_port}
      - DATABASE_NAME=${database_name}
      - DATABASE_USERNAME=${database_username}
      - DATABASE_PASSWORD=${database_password}
      - HOST=0.0.0.0
      - PORT=${strapi_port}
    ports:
      - "${strapi_port}:${strapi_port}"
    volumes:
      - strapi-data:/srv/app
    networks:
      - strapi-network
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:${strapi_port}/_health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s

volumes:
  strapi-data:
    driver: local

networks:
  strapi-network:
    driver: bridge
EOF

# Create .env file with environment variables
echo "=== Creating environment file ==="
cat > /opt/strapi/.env <<'ENVEOF'
NODE_ENV=${node_env}
APP_KEYS=${app_keys}
API_TOKEN_SALT=${api_token_salt}
ADMIN_JWT_SECRET=${admin_jwt_secret}
TRANSFER_TOKEN_SALT=${transfer_token_salt}
JWT_SECRET=${jwt_secret}
DATABASE_CLIENT=${database_client}
DATABASE_HOST=${database_host}
DATABASE_PORT=${database_port}
DATABASE_NAME=${database_name}
DATABASE_USERNAME=${database_username}
DATABASE_PASSWORD=${database_password}
ENVEOF

# Set proper permissions
chmod 600 /opt/strapi/.env

# Pull Strapi image
echo "=== Pulling Strapi Docker image ==="
docker pull strapi/strapi:latest

# Start Strapi with Docker Compose
echo "=== Starting Strapi application ==="
cd /opt/strapi
docker-compose up -d

# Create systemd service for auto-start
echo "=== Creating systemd service ==="
cat > /etc/systemd/system/strapi.service <<'SERVICEEOF'
[Unit]
Description=Strapi CMS
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/strapi
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
SERVICEEOF

# Enable the service
systemctl daemon-reload
systemctl enable strapi.service

# Wait for Strapi to be healthy
echo "=== Waiting for Strapi to start ==="
for i in {1..30}; do
  if docker exec strapi wget --spider -q http://localhost:${strapi_port}/_health 2>/dev/null; then
    echo "Strapi is running!"
    break
  fi
  echo "Waiting for Strapi... ($i/30)"
  sleep 10
done

# Install CloudWatch agent (optional)
echo "=== Installing CloudWatch agent ==="
wget https://s3.amazonaws.com/amazoncloudwatch-agent/amazon_linux/amd64/latest/amazon-cloudwatch-agent.rpm
rpm -U ./amazon-cloudwatch-agent.rpm
rm -f ./amazon-cloudwatch-agent.rpm

# Create log directory
mkdir -p /var/log/strapi

# Setup log forwarding from Docker to CloudWatch (basic setup)
cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json <<'CWEOF'
{
  "logs": {
    "logs_collected": {
      "files": {
        "collect_list": [
          {
            "file_path": "/var/lib/docker/containers/*/*.log",
            "log_group_name": "/aws/ec2/strapi",
            "log_stream_name": "{instance_id}",
            "timezone": "UTC"
          }
        ]
      }
    }
  }
}
CWEOF

# Start CloudWatch agent
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl \
  -a fetch-config \
  -m ec2 \
  -s \
  -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json

echo "=== Installation complete! ==="
echo "Strapi is running on port ${strapi_port}"
echo "Check status: docker ps"
echo "View logs: docker logs strapi"
