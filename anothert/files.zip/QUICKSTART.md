# Quick Start Guide - Strapi on AWS

Get your Strapi CMS running on AWS in under 30 minutes!

## Prerequisites Checklist

- [ ] AWS Account with admin access
- [ ] AWS CLI installed and configured
- [ ] Terraform >= 1.0 installed
- [ ] SSH key pair generated

## Step-by-Step Deployment

### 1. Generate SSH Key (if you don't have one)

```bash
ssh-keygen -t rsa -b 4096 -C "your-email@example.com" -f ~/.ssh/strapi-key
```

Your public key will be at: `~/.ssh/strapi-key.pub`

### 2. Generate Strapi Secrets

```bash
cd terraform-strapi-deployment
./generate-secrets.sh
```

Copy the output - you'll need it in the next step.

### 3. Configure Your Environment

Edit `terraform.dev.tfvars`:

```bash
vim terraform.dev.tfvars
```

**Required Changes:**

1. **Add your SSH public key:**
   ```bash
   # Get your public key
   cat ~/.ssh/strapi-key.pub
   ```
   
   Copy the output and paste it into the `ssh_public_key` variable:
   ```hcl
   ssh_public_key = "ssh-rsa AAAAB3NzaC1yc2E... your-email@example.com"
   ```

2. **Add the Strapi secrets** (from step 2):
   ```hcl
   strapi_app_keys           = "key1,key2,key3,key4"
   strapi_api_token_salt     = "your-generated-salt"
   strapi_admin_jwt_secret   = "your-generated-secret"
   strapi_transfer_token_salt = "your-generated-salt"
   strapi_jwt_secret         = "your-generated-secret"
   ```

3. **Optional:** Update AWS region and other settings as needed.

### 4. Deploy Infrastructure

**Option A: Using the deployment script (Recommended)**

```bash
# Plan deployment
./deploy.sh dev plan

# Review the plan, then apply
./deploy.sh dev apply
```

**Option B: Using Terraform commands directly**

```bash
# Initialize Terraform
terraform init

# Plan deployment
terraform plan -var-file="terraform.dev.tfvars"

# Apply deployment
terraform apply -var-file="terraform.dev.tfvars"
```

Type `yes` when prompted to confirm.

### 5. Wait for Deployment

The deployment process takes approximately **20-25 minutes**:
- Infrastructure creation: ~10 minutes
- EC2 instance launch: ~5 minutes
- Docker + Strapi setup: ~5-10 minutes

### 6. Access Your Strapi Instance

Get the ALB URL:

```bash
terraform output alb_url
```

Or:

```bash
terraform output -raw alb_url && echo
```

**Example output:** `http://strapi-app-alb-1234567890.us-east-1.elb.amazonaws.com`

### 7. Complete Strapi Setup

1. Open the ALB URL in your browser
2. Navigate to `/admin` (e.g., `http://your-alb-url/admin`)
3. Create your first administrator account:
   - First name
   - Last name
   - Email
   - Password

🎉 **Congratulations! Your Strapi CMS is now running on AWS!**

## Verification Checklist

After deployment, verify everything is working:

- [ ] ALB URL loads successfully
- [ ] Strapi admin panel accessible at `/admin`
- [ ] Health check endpoint works: `http://your-alb-url/_health`
- [ ] Can create admin account
- [ ] Can log in to admin panel

## Quick Commands Reference

### View All Outputs
```bash
terraform output
```

### Get Specific Output
```bash
terraform output alb_url
terraform output ec2_instance_id
terraform output vpc_id
```

### Connect to EC2 Instance (via SSM)
```bash
# Get instance ID first
INSTANCE_ID=$(terraform output -raw ec2_instance_id)

# Connect
aws ssm start-session --target $INSTANCE_ID --region us-east-1
```

### Check Docker Status on EC2
```bash
# After connecting via SSM
docker ps
docker logs strapi
```

### View Strapi Logs
```bash
# On EC2 instance
docker logs strapi -f
```

## Common Issues & Solutions

### Issue: ALB health check failing

**Solution:**
```bash
# Connect to EC2 and check Strapi status
docker ps
docker logs strapi

# Check if Strapi is responding
curl http://localhost:1337/_health
```

### Issue: Cannot access Strapi admin

**Solution:**
1. Wait 2-3 minutes for Strapi to fully start
2. Check if container is running: `docker ps`
3. Check logs: `docker logs strapi`

### Issue: Terraform apply fails

**Solution:**
1. Check AWS credentials: `aws sts get-caller-identity`
2. Verify Terraform is initialized: `terraform init`
3. Check for syntax errors in .tfvars file

### Issue: EC2 instance not starting

**Solution:**
1. Check CloudWatch logs: `/var/log/cloud-init-output.log`
2. View user data logs on EC2: `cat /var/log/cloud-init-output.log`

## Next Steps

### 1. Configure Custom Domain (Optional)

1. Get a domain name
2. Create Route 53 hosted zone
3. Create CNAME record pointing to ALB DNS
4. Request ACM certificate
5. Add HTTPS listener to ALB

### 2. Set Up Production Database

For production, use RDS PostgreSQL:

1. Create RDS instance
2. Update `terraform.prod.tfvars`:
   ```hcl
   strapi_database_client   = "postgres"
   strapi_database_host     = "your-rds-endpoint"
   strapi_database_port     = 5432
   strapi_database_name     = "strapi"
   strapi_database_username = "strapiuser"
   strapi_database_password = "secure-password"
   ```
3. Redeploy

### 3. Enable Monitoring

- Set up CloudWatch dashboards
- Configure alarms for:
  - High CPU usage
  - Failed health checks
  - Low disk space

### 4. Configure Backups

- Enable EBS snapshots
- Set up S3 backup for media files
- Configure RDS automated backups

## Cost Management

### Reduce Costs for Development

In `terraform.dev.tfvars`:
```hcl
# Use smaller instance
instance_type = "t3.small"

# Use only 1 NAT Gateway
az_count = 1
```

### Stop When Not in Use

```bash
# Stop EC2 instance
aws ec2 stop-instances --instance-ids $(terraform output -raw ec2_instance_id)

# Start EC2 instance
aws ec2 start-instances --instance-ids $(terraform output -raw ec2_instance_id)
```

**Note:** NAT Gateway costs continue even when EC2 is stopped.

## Clean Up

When you're done testing:

```bash
# Using deployment script
./deploy.sh dev destroy

# Or using Terraform directly
terraform destroy -var-file="terraform.dev.tfvars"
```

Type `yes` to confirm deletion.

## Getting Help

1. Check logs:
   - CloudWatch: `/aws/ec2/strapi`
   - EC2: `/var/log/cloud-init-output.log`
   - Docker: `docker logs strapi`

2. Review Terraform output: `terraform output`

3. Verify security groups allow traffic

4. Check [Strapi Documentation](https://docs.strapi.io/)

## Production Deployment

When ready for production:

1. Update `terraform.prod.tfvars` with production values
2. Use stronger instance type (t3.large or larger)
3. Enable deletion protection
4. Use RDS for database
5. Set up HTTPS with ACM certificate
6. Configure monitoring and alerting
7. Set up regular backups

```bash
./deploy.sh prod plan
./deploy.sh prod apply
```

---

**Need Help?** Review the main README.md and ARCHITECTURE.md files for detailed information.
